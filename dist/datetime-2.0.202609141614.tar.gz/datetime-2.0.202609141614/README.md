# datetime

A small C99 program that prints the current datetime, computed in the host machine's timezone or UTC, with full GNU `date` compatible options. Extends the original legacy formats with GNU `date` semantics (`-d`, `-f`, `-I`, `-R`, `--rfc-3339`, `-r`, `-s`, `-u`, `--debug`, `--resolution`, and custom `+FORMAT`).

Legacy formats are kept for backward compatibility; new options follow the GNU `date` interface.

> **Build vs. deploy:** `make` only builds `datetime` + `timestamp` into the repo root – it does **not** install anything. Run `make install` (optionally with `PREFIX=...`) to deploy the binaries, man page and bash completions; `make uninstall` removes them.

## Index

* [Output formats](#output-formats)
  * [Legacy (backward compatible)](#legacy-backward-compatible)
  * [GNU date compatible](#gnu-date-compatible)
* [Usage](#usage)
* [Implementation notes](#implementation-notes)
* [Tests](#tests)
* [Memory and security checks](#memory-and-security-checks)
* [Build](#build)
  * [macOS (Darwin) – Intel, Apple Silicon & external drives](#macos-darwin--intel-apple-silicon--external-drives)
* [Install (explicit)](#install-explicit)
* [Clean](#clean)
* [Example usage](#example-usage)
  * [Basic and version/help](#basic-and-versionhelp)
  * [Legacy output formats](#legacy-output-formats-kept-datetimec52-formats)
  * [GNU date compatible – date source](#gnu-date-compatible--date-source)
  * [File and reference](#file-and-reference)
  * [ISO-8601 / RFC / resolution / UTC](#iso-8601--rfc--resolution--utc)
  * [Custom FORMAT](#custom-format-all-gnu-sequences-flags-width-modifiers)
  * [Set time](#set-time-requires-root-otherwise-warns-but-prints)
  * [Error and exclusivity](#error-and-exclusivity-mutually-exclusive---date--file--reference--resolution)
* [Timestamp utility and microversion (`x.y.<UTC>`)](#timestamp-utility-and-microversion-xyutc)
  * [What it is](#what-it-is)
  * [How to use it](#how-to-use-it)
  * [Why this exact form](#why-this-exact-form-yyyymmddhhmmssz)
* [Help files](#help-files)

## Output formats

### Legacy (backward compatible)

<!-- BEGIN GENERATED: format-table -->
| Invocation                           | Output                                                         |
|---------------------------------------|----------------------------------------------------------------|
| `datetime` (default)                  | `YYYYMMDDhhmmss`                                               |
| `datetime -hr, --human-readable`      | `YYYY-MM-DD hh:mm:ss`                                          |
| `datetime -c, --compact`              | `YYYYMMDDThhmmss`                                              |
| `datetime -cd, --calendar-date`       | `YYYY-MM-DD`                                                   |
| `datetime -cdb, --calendar-date-base` | `YYYYMMDD`                                                     |
| `datetime -od, --ordinal-date`        | `YYYY-DDD`                                                     |
| `datetime -odb, --ordinal-date-base`  | `YYYYDDD`                                                      |
| `datetime -wd, --week-date`           | `YYYY-Www-D`                                                   |
| `datetime -wdb, --week-date-basic`    | `YYYYWwwD`                                                     |
| `datetime --timestamp`                | `YYYYMMDDhhmmssZ` (UTC/GMT, compact seconds for micro version) |
<!-- END GENERATED: format-table -->

The timezone is used to compute the local time but is not part of the datetime output for legacy formats. It is reported by `--version` and `--help`.

### GNU date compatible

```
Usage: datetime [OPTION]... [+FORMAT]
  or:  datetime [OPTION]... [MMDDhhmm[[CC]YY][.ss]]
Display date and time in the given FORMAT.
With -s, or with MMDDhhmm[[CC]YY][.ss], set the date and time first.

Mandatory arguments to long options are mandatory for short options too.
  -d, --date=STRING          display time described by STRING, not 'now'
      --debug                annotate parsed date, warn to stderr
  -f, --file=DATEFILE        like --date; once for each line of DATEFILE; if DATEFILE is -, read stdin
  -I[FMT], --iso-8601[=FMT]   ISO 8601: FMT='date'(default), 'hours', 'minutes', 'seconds', 'ns'
      --resolution           output available resolution of timestamps (0.000000001)
  -R, --rfc-email            RFC 5322: e.g. Mon, 14 Aug 2006 02:34:56 +0000
      --rfc-3339=FMT         RFC 3339: FMT='date', 'seconds', or 'ns'
  -r, --reference=FILE       display last modification time of FILE
  -s, --set=STRING           set time described by STRING (requires root; otherwise warns and prints what would be set)
  -u, --utc, --universal     print or set Coordinated Universal Time (UTC)
      --help                 display this help and exit
      --version              output version information and exit
```

All options that specify the date to display are mutually exclusive: `--date`, `--file`, `--reference`, `--resolution`.

`FORMAT` controls the output. Interpreted sequences are the same as GNU `date` (see `man datetime` or `date --help`):

```
%%   literal %     %a   abbrev weekday (Sun)   %A   full weekday (Sunday)
%b   abbrev month  %B   full month             %c   locale datetime
%C   century       %d   day of month 01        %D   %m/%d/%y
%e   space-pad day %F   %Y-%m-%d               %g/%G ISO week year
%h   == %b        %H   hour 00-23             %I   hour 01-12
%j   day of year  %k   space-pad hour         %l   space-pad 12h
%m   month 01-12   %M   minute 00-59           %n   newline
%N   nanoseconds   %p   AM/PM                  %P   am/pm
%q   quarter 1-4   %r   12h time               %R   %H:%M
%s   seconds since Epoch  %S second 00-60    %t   tab
%T   %H:%M:%S      %u   weekday 1-7 Mon=1       %U   week number Sun first
%V   ISO week      %w   weekday 0-6 Sun=0       %W   week number Mon first
%x   locale date   %X   locale time            %y   year 00-99
%Y   year         %z   +hhmm                  %:z  +hh:mm
%::z +hh:mm:ss    %:::z minimal +hh[:mm[:ss]]  %Z   alphabetic TZ
```

Padding flags after `%`: `-` (no pad), `_` (space), `0` (zero), `+` (zero + '+' for >4 digit years), `^` (upper), `#` (swap case), optional width, optional `E`/`O` modifier.

Full documentation is in this README, the manual (`info datetime` from `manual.texi`), and the man page (`man/man1/datetime.1`).

## Usage

```sh
./datetime                         # e.g. 20260909101032
./datetime -hr                     # e.g. 2026-09-09 10:10:32
./datetime -c                      # e.g. 20260909T101032
./datetime -wd                     # e.g. 2026-W37-3
./datetime --version               # show version (with build number) and host timezone
./datetime -V                      # same as --version
./datetime -h                      # show help
./datetime --help                  # show help

# GNU date compatible
./datetime -u +"%Y-%m-%d %H:%M:%S %Z"               # UTC custom format
./datetime -d '@2147483647'                         # epoch -> date
./datetime -d '2020-01-02 03:04:05' +"%F %T"          # parse string
./datetime --debug -d '2020-01-02'                  # annotated parsing to stderr
./datetime -I                                       # ISO 8601 date
./datetime -Iseconds                                # ISO 8601 with seconds and zone
./datetime --iso-8601=ns                            # ISO 8601 nanoseconds
./datetime -R                                       # RFC 5322 / RFC email
./datetime --rfc-3339=seconds                       # RFC 3339
./datetime -r Makefile +"%F"                        # file modification time
./datetime -f dates.txt +"%F"                       # each line as --date
printf "2020-01-02\n2020-01-03\n" | ./datetime -f - +"%F"  # stdin via -
./datetime --resolution                             # 0.000000001
./datetime -u -d 'TZ="America/Los_Angeles" 09:00 next Fri'  # TZ prefix
./datetime --set='2020-01-02 00:00:00'               # set system time (needs root)
./datetime 09091100                                 # MMDDhhmm form (set)
```

## Implementation notes

* **Parsing `STRING` (`-d`/`--date`/`--set`/`-f`)** supports:
  * `@EPOCH[.NANO]` (e.g. `@0`, `@2147483647`, `@123.456789123`)
  * `YYYY-MM-DD`, `YYYY-MM-DD HH:MM:SS`, `YYYY/MM/DD`, `MM/DD/YY`, ISO `T` variants, RFC 2822/5322
  * `now`, `today`, `yesterday`, `tomorrow`
  * Any string understood by host GNU `date -d` as fallback (including relative `next Fri`, `+1 day`, `2 weeks ago`)
  * `TZ="Zone" <STRING>` prefix – temporarily sets `TZ` for parsing and formatting
* **Timezone handling**: `-u` uses `gmtime_r`; otherwise `localtime_r`. `tm_gmtoff` is used to synthesize `%z`, `%:z`, `%::z`, `%:::z` portably when `strftime` lacks `%:z`.
* **ISO-8601 / RFC-3339**: `seconds` and `ns` include `%:z`; `ns` includes `.%N`.
* **Mutual exclusivity** enforced for `--date`/`--file`/`--reference`/`--resolution`.
* **`--debug`** prints `debug: ...` to stderr, including parsed `time_t` and format decisions, and warns on questionable usage.
* **Memory / security**: All inputs bounded (`4096` for date strings, `8192` for formats), `snprintf`/`strncpy` with truncation, `strdup` matched with `free`, `shell_escape` escapes `'` as `'\''` before `popen` to `date -d`. No fixed `strcpy`/`strcat`/`sprintf`. Validated with `valgrind --leak-check=full` and `gcc -fsanitize=address`.

## Tests

All suites live in `tests/`; the root runner executes everything and is wired
into `make check`:

```sh
./_tests              # one summary line per suite
./_tests --details    # per-case output: parameters + result, OK green, FAILED red
```

Current totals: 693 checks (140 bash + 267 matrix + 284 combinatorial + 40 Python with 244 subtests):

* `tests/_test_matrix` – 267-case differential suite: every option and an option-combination matrix, each compared against the installed GNU `date` with compatible arguments (same exit codes, same stdout; ns-resolution and `-I ns`/`--rfc-3339=ns` compared with clock-race tolerance). Options where we deliberately deviate from or extend GNU (compact 14-digit dates, bare `TZ=` prefix, `-I=seconds` spelling, dot instead of comma in ISO ns) are asserted against the documented behavior instead. Also prints one line per case under `--details`.
  ```sh
  ./tests/_test_matrix [--details]
  ```
* `tests/_test_datetime` – 124 bash tests (legacy, GNU options, FORMAT flags, edge cases, security). Run from repo root:
  ```sh
  ./tests/_test_datetime
  ```
* `tests/_test_combinatorial` – 284 bash exhaustive matrix (every alias, every `-I`/`--rfc-3339` variant, all 6 mutually-exclusive pairs + triples, `-u`/`--debug` × each date source, `+FORMAT` × each source, all 47 FORMAT sequences `%%`..`%Z` with/without `-u`, flags `-_0+^#`, width, `E/O`, alias equivalence, error cases, injection/long-input):
  ```sh
  ./tests/_test_combinatorial
  ```
* `tests/test_granular.py` – 24 Python `unittest`/`pytest` tests covering the same matrix plus comparison with GNU date behavior:
  ```sh
  python3 -m pytest tests/test_granular.py -v
  # or
  python3 tests/test_granular.py
  ```
* `tests/test_exhaustive.py` – 16 Python exhaustive matrix (235 subtests via `itertools.product`): legacy singletons, `iso-8601`×5 × short/long, `rfc-3339`×3, `r`/`f`/`s` aliases, `utc` aliases (`-u`/`--utc`/`--universal`), date sources (`@0`/`now`/`today`/fractional/`TZ=`), mutual-exclusivity full `C(4,2)+C(4,3)` matrix, compatible `-u`/`--debug`×each base, all `FORMAT` sequences with/without `-u`, flag×width×`E/O` matrix, error/long-input/injection:
  ```sh
  python3 -m pytest tests/test_exhaustive.py -v
  # or
  python3 -m pytest tests/test_granular.py tests/test_exhaustive.py -v
  ```

All suites together validate combinatorially:
* every singleton option and every alias (`-d`/`--date=`/`--date`, `-f`/`--file=`, `-r`/`--reference=`, `-s`/`--set=`, `-u`/`--utc`/`--universal`, `-R`/`--rfc-email`, `-I`/`--iso-8601`, `-h`/`--help`, `-V`/`--version`)
* every `FMT` variant (`--iso-8601:date/hours/minutes/seconds/ns`, `--rfc-3339:date/seconds/ns`)
* FORMAT sequences `%%`..`%Z` (`%a`..`%Z`, `%z/%:z/%::z/%:::z`, `%N`, `%q`, `%s`) with/without `-u` and with flags `-_0+^#`, width `1/2/5/10`, modifiers `E/O`
* mutual exclusivity errors (all 6 pairs + triples among `--date`/`--file`/`--reference`/`--resolution`), missing/invalid args, unknown options (`-Z`/`--unknown`)
* compatible pairs/triples (`-u`×each, `--debug`×each, `+FORMAT`×each date source, legacy vs GNU last-wins, `-f` `-u` `--debug` matrix, `TZ=` prefix, `MMDDhhmm` positional)
* TZ prefix, fractional epoch (`@1234567890.123456789`), stdin `-`, long inputs (5000+ chars), shell-injection attempt (`'; touch /tmp/pwned; echo '`)
* buffer overflow with many specifiers (200×`%Y`), ESC-free help (`! grep -q $'\x1b'`), renamed-binary run (no `argv0` dispatch)

## Memory and security checks

```sh
make check              # syntax + valgrind for the datetime binary
# extended valgrind matrix
for cmd in "./datetime -d '@0'" "./datetime -f dates.txt +\"%F\"" "./datetime -u -Iseconds" "./datetime -R" "./datetime --rfc-3339=ns" "./datetime -r Makefile" "./datetime --set='2020-01-02'"; do
  valgrind --leak-check=full --show-leak-kinds=all --error-exitcode=1 $cmd
done
# address sanitizer
gcc -fsanitize=address -o /tmp/datetime_san datetime.c && /tmp/datetime_san -d '@0' && echo ok
```

All heap blocks are freed (`All heap blocks were freed -- no leaks are possible`); error summary `0 errors from 0 contexts`.

## Build

> **C Standard: C99** – This project is written in **strict C99** (`project.toml:5` `standard = "C99"`, `Makefile:2` `CFLAGS ?= -O2 -Wall -Wextra -std=c99`, `datetime.c:1` `// Expose POSIX + GNU timezone functions under strict C99.`). Code compiles with `gcc -std=c99` and only uses the standard C library (`libc`) plus POSIX/GNU extensions exposed via `_DEFAULT_SOURCE` / `_POSIX_C_SOURCE 200809L` / `_XOPEN_SOURCE 700` for `gmtime_r`/`localtime_r`/`timegm`/`strptime`/`clock_gettime` – no external libraries, no C11/C17 features. This guarantees portability to any C99 compiler while still accessing timezone and high-resolution clock APIs. All format handling uses `strftime` with manual fallback for `%N`/`%q`/`%s`/`%z` variants to stay C99-compliant. `project.toml:19` documents `c_standard = "libc"` and `c_posix_features` list.

> **GNU C Styleguide:** This codebase follows the [GNU Coding Standards](gnu_c_stileguide.md) (`gnu_c_stileguide.md:8` *Formatting Your Source Code*, `gnu_c_stileguide.md:10` *Clean Use of C Constructs*, `gnu_c_stileguide.md:13` *Program Behaviour*). Compliance is enforced via `Makefile:1` `SHELL = /bin/sh`, standard `prefix`/`bindir`/`mandir` variables `Makefile:5`, `INSTALL_PROGRAM`/`INSTALL_DATA` `Makefile:22`, `distclean`/`TAGS`/`dist` targets `Makefile:55`, function braces in column zero `datetime.c:38` (`debug_log` `(` → `\n{`), `getopt_long` for CLI `datetime.c:779` `Standards for Command Line Interfaces` `gnu_c_stileguide.md:17`, dynamic allocation instead of fixed `4096` limits `datetime.c:480` (`malloc`/`obstack` per `gnu_c_stileguide.md:13`), and Texinfo `manual.texi:1` / `ChangeLog:1` / `NEWS:1`.

Requirements:

- A C99 compiler (`gcc` recommended, tested with `gcc 13+`; `clang` also works with `-std=c99`)
- `make` (GNU make)
- `valgrind` (only for the memory-leak check)
- `bash` + `coreutils` (`date`, `install`, `touch`) for tests and `BUILD` fallback
- `python3` + `pytest` (optional, for `tests/test_granular.py` / `tests/test_exhaustive.py`)

On Fedora, install them with:

```sh
sudo dnf install gcc make valgrind bash coreutils python3 pytest
```

On Debian/Ubuntu:

```sh
sudo apt install gcc make valgrind bash coreutils python3 python3-pytest
```

Build the binaries (does **not** install – run `make install` separately):

```sh
make          # builds datetime + timestamp into the repo root
make install  # installs to $(prefix)/bin, $(prefix)/share/man/man1 + bash completions
```

Tip: `./_make` shows an interactive menu over all Makefile targets (`./_make --list` to print it, `./_make <target>` to run without the menu, custom `make` args pass through, e.g. `./_make install PREFIX="$HOME"`).

`make` builds only; `make install` deploys. Per the GNU Coding Standards, `prefix` defaults to `/usr/local` – binaries land in `/usr/local/bin` and the man page in `/usr/local/share/man/man1`. To install into your home directory instead, override `PREFIX`:

```sh
PREFIX="$HOME" make install   # ~/bin/{datetime,timestamp} + ~/.local/share/man/man1/datetime.1
PREFIX="$HOME/sbin" make install  # classic ~/sbin layout, man page still in $HOME/sbin/share/man
```

`DESTDIR` is honored for staged/packaged installs (`make install DESTDIR=/tmp/pkg`), and `make uninstall` removes exactly what `install` laid down. The old behavior (`make` auto-installing to `~/sbin`) was removed in Task 16 per GNU Coding Standards §7.2.2 – `all` and `install` are separate targets.

The version is a single hardcoded constant, `__version__` in `datetime.c` (currently `2.0.202609131714`). Bump it there when releasing; there is no generated header or compiler define involved. See it with `./datetime --version`.

Run the checks (syntax + memory leaks + security + style + test suites + doc drift):

```sh
make check
./tests/_test_datetime
./tests/_test_combinatorial
python3 -m pytest tests/test_granular.py tests/test_exhaustive.py -v
```

The security part (`make check-security`) scans for banned libc APIs (`gets`, `strcpy`, `sprintf`, ...), runs `gcc -fanalyzer`, and an ASan/LeakSanitizer battery over ~30 success/error/stdin paths; UBSan runs when available (skip-with-notice by default, `STRICT=1` to fail instead). Or just run `./_make` and pick the check from the menu.

### macOS (Darwin) – Intel, Apple Silicon & external drives

> `macOS` is `BSD` (`Darwin`), not `Linux` (`GNU`). `Makefile:1` and `datetime.c:1` handle it, but `install` and `deploy` differ.

**Prerequisites – Xcode CLT + Homebrew:**
```sh
xcode-select --install                          # clang -std=c99, make, BSD install
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install gcc make coreutils bash python3    # GNU make as gmake if needed: brew install make
# valgrind is NOT supported on macOS ≥10.15 – use ASan/ leaks instead:
brew install llvm                               # for clang-format --style=GNU
```

**Build – same command, `C99` + `BSD` portable `install`:**
```sh
make                                            # builds datetime + timestamp (timestamp defaults to the UTC micro-version format)
# Makefile:1 SHELL=/bin/sh, Makefile:22 INSTALL = install, INSTALL_PROGRAM = $(INSTALL) -m 0755
# BSD install has no -D – Makefile:74 uses portable mkdir -p $(DESTDIR)$(bindir) before install
./datetime --version                             # datetime 2.0.2026090909XXXXZ (UTC)
```

**Deploy paths – auto-detected (`Makefile:4` `UNAME_S := $(shell uname -s)`):**

| Machine | `uname -s` | Default `prefix`/`bindir` (`Makefile:4`) | Real path | Override |
|---------|------------|-------------------------------------------|-----------|----------|
| `Intel` `macOS` | `Darwin` | `prefix=/usr/local` → `bindir=/usr/local/bin` | `/usr/local/bin/datetime` | `make prefix=/usr/local` |
| `Apple Silicon` | `Darwin` + `test -d /opt/homebrew` | `prefix=/opt/homebrew` → `bindir=/opt/homebrew/bin` | `/opt/homebrew/bin/datetime` | `make prefix=/opt/homebrew` |
| `Linux` / other Unix | `Linux` | `prefix=/usr/local` → `bindir=/usr/local/bin` | `/usr/local/bin/datetime` | `make PREFIX="$HOME" install` → `~/bin/datetime` |
| `External drive` (common on small `SSD` `Mac`s – `Applications` moved to `/Volumes/External`) | `Darwin` + `df /Applications` → `/Volumes/External` | **Not auto-detected for CLI** – `bindir` stays as above | `/Volumes/External/opt/homebrew/bin` or `/Volumes/External/sbin` | `make prefix=/Volumes/External/opt/homebrew` or `make bindir=/Volumes/External/sbin` or `make bindir=/Volumes/External/Applications/bin` |

**How to find the correct `macOS` deploy path when `Applications` is on external:**
```sh
# 1. Where is the real Applications folder? (handles symlink /Volumes/External/Applications)
osascript -e 'POSIX path of (path to applications folder)' 2>/dev/null | tr -d ':'
# or
readlink /Applications
df /Applications | tail -1 | awk '{print $6}'  # mount point, e.g. /Volumes/External

# 2. Where is Homebrew? (may be on external)
brew --prefix  # -> /opt/homebrew or /Volumes/External/opt/homebrew
which datetime # -> /opt/homebrew/bin/datetime or /Users/you/sbin/datetime

# 3. Override at install time (already supported, no code change needed)
make bindir=/Volumes/External/bin install
make prefix=/Volumes/External/opt/homebrew install
make PREFIX="$HOME/sbin" install         # keep classic ~/sbin even on macOS
```

**External drive is covered:** `install` uses `$(DESTDIR)$(bindir)` – `prefix`/`bindir`/`mandir` are fully overridable (`make prefix=... install` or `make PREFIX=... install`), and on Homebrew the auto-detected `/opt/homebrew` prefix already follows `brew --prefix` even when Homebrew lives on an external volume. No hard-coded `/Applications` is used for CLI tools – the table above shows how to detect it via `osascript`/`df`/`brew --prefix`.

**`macOS` quirks handled in code:**
* `datetime.c:22` `#if defined(__linux__) || defined(__APPLE__)` for `<sys/time.h>` (`timespec` in `<time.h>` on `Darwin`, `clock_gettime` ≥10.12, `timegm` ≥10.6, `tm_gmtoff`/`tm_zone` available as `BSD` extension).
* `datetime.c:20` `#ifdef _WIN32` vs `#else` `#include <getopt.h>` – `macOS` `BSD` `getopt_long` supports `I::` optional arg differently, handled via filtered `argv` before `getopt_long` `datetime.c:860`.
* `valgrind` → use `leaks`/`ASan` on `macOS`: `make check-mem` will warn `valgrind not found`, run `clang -fsanitize=address -o /tmp/datetime_asan datetime.c && /tmp/datetime_asan -d "@0"`.

**`Windows` (`MinGW-w64`/`MSYS2`) install paths:** `make install` places `datetime.exe` in `$(HOME)/sbin` and the man page in `$(HOME)/.local/share/man/man1`.

## Install (explicit)

Installs `datetime`, `timestamp` and the man page to the GNU-standard directories under `prefix` (default `/usr/local`), plus the bash completion script into bash-completion's `completionsdir` (auto-detected via `pkg-config`, fallback `$(prefix)/share/bash-completion/completions`). The two binaries are the same program: `timestamp` is compiled with `-DDATETIME_TIMESTAMP_BUILD` so its **default** output is the UTC `YYYYMMDDhhmmssZ` stamp – every option (`-d`, `-I`, `+FORMAT`, ...) works identically in both. Run-time behavior never depends on `argv[0]`: `datetime --timestamp` selects the same format:

```sh
make install                # $(prefix)/bin/{datetime,timestamp} + man page + bash completions
make install DESTDIR=/tmp/pkg  # staged install for packaging
```

User-local example:

```sh
PREFIX="$HOME" make install   # ~/bin/datetime, ~/.local/share/man/man1/datetime.1
```

Remove it with (removes exactly what `install` created, including any legacy `~/sbin` copies):

```sh
make uninstall
```

## Clean

```sh
make clean
```

## Example usage

Extensive examples covering every option and `FORMAT` – all are tested in `tests/_test_datetime:1`, `tests/_test_combinatorial:1`, `tests/test_exhaustive.py:1`.

### Basic and version/help (C99 `datetime --help` is ESC-free, 134 lines)
```sh
./datetime                          # default: 20260909103730 (YYYYMMDDhhmmss)
./datetime --help                   # full help
./datetime -h                       # same as --help
./datetime --version                # datetime 2.0.20260909083730Z + Timezone: CEST (UTC+2)
./datetime -V                       # same as --version
./datetime --debug -d "2020-01-02" +"%F"  # debug to stderr: parsing + format decisions
./timestamp                         # default: 20260909103730Z (UTC YYYYMMDDhhmmssZ)
./timestamp --help                  # same options as datetime, default is UTC stamp
./timestamp -h                      # same as --help
./timestamp --version               # timestamp 2.0.20260909083730Z
```

### Legacy output formats (kept, `datetime.c:52` formats[])
```sh
./datetime -hr              # 2026-09-09 10:37:30 (human readable)
./datetime --human-readable # same
./datetime -c               # 20260909T103730 (compact, ISO 8601 basic)
./datetime --compact
./datetime iso-basic        # same as -c (without dash)
./datetime -cd              # 2026-09-09
./datetime --calendar-date
./datetime -cdb             # 20260909
./datetime --calendar-date-base
./datetime -od              # 2026-252 (ordinal, DDD 001..366)
./datetime --ordinal-date
./datetime -odb             # 2026252
./datetime --ordinal-date-base
./datetime -wd              # 2026-W37-3 (ISO week, 1=Mon..7=Sun)
./datetime --week-date
./datetime -wdb             # 2026W373
./datetime --week-date-basic
./datetime --timestamp      # 20260909103730Z (UTC, micro-version format)
```

### GNU date compatible – date source
```sh
./datetime -d "@0" +"%F %T"                 # epoch 0 UTC -> 1970-01-01 01:00:00 (local) / 00:00:00 with -u
./datetime -u -d "@0" +"%F %T %Z"           # 1970-01-01 00:00:00 UTC
./datetime -d "@2147483647" -u +"%F %T"     # 2038-01-19 03:14:07 (32-bit max)
./datetime -d "@1234567890.123456789" -u +"%s.%N" # fractional epoch with nanoseconds
./datetime -d "2020-01-02" +"%F"            # 2020-01-02
./datetime -d "2020-01-02 03:04:05" +"%F %T"
./datetime -d "2020/01/02" +"%F"
./datetime -d "01/02/20" +"%F"              # MM/DD/YY
./datetime -d "now" +"%F %T"
./datetime -d "today" +"%F"
./datetime -d "yesterday" +"%F"
./datetime -d "tomorrow" +"%F"
./datetime -d "TZ=\"UTC\" 2020-01-02 03:04:05" -u +"%T" # TZ prefix: parse in UTC
./datetime -d 'TZ="America/Los_Angeles" 09:00 next Fri' +"%F %a" # relative + TZ
```

### File and reference
```sh
printf "2020-01-02\n2020-01-03\n" > dates.txt
./datetime -f dates.txt +"%F"              # each line as --date
./datetime --file=dates.txt +"%F"
printf "2020-01-02\n" | ./datetime -f - +"%F"  # stdin via -
touch -d "2020-01-02 03:04:05" ref
./datetime -r ref +"%F %T"                 # last modification time
./datetime --reference=ref +"%F"
```

### ISO-8601 / RFC / resolution / UTC
```sh
./datetime -I                  # 2026-09-09 (date, default)
./datetime --iso-8601          # same
./datetime -Ihours             # 2026-09-09T10+02:00
./datetime --iso-8601=minutes  # 2026-09-09T10:37+02:00
./datetime -Iseconds           # 2026-09-09T10:37:30+02:00
./datetime --iso-8601=ns       # 2026-09-09T10:37:30.123456789+02:00
./datetime -u -Iseconds        # +00:00 in UTC
./datetime -R                  # Wed, 09 Sep 2026 10:37:30 +0200 (RFC 5322)
./datetime --rfc-email
./datetime --rfc-3339=date     # 2026-09-09
./datetime --rfc-3339=seconds  # 2026-09-09 10:37:30+02:00
./datetime --rfc-3339=ns       # 2026-09-09 10:37:30.123456789+02:00
./datetime --resolution        # 0.000000001 (nanosecond)
./datetime -u +"%Y-%m-%d %H:%M:%S %Z"  # UTC mode
./datetime --utc +"%F"
./datetime --universal +"%Z"   # alias of -u
```

### Custom FORMAT (all GNU sequences, flags, width, modifiers)
```sh
./datetime -d "2020-01-02" +"%a %A %b %B %c"   # Thu Thursday Jan January ...
./datetime -d "2020-01-02" +"%C %d %D %e %F"   # 20 02 01/02/20  2 2020-01-02
./datetime -d "2020-01-02" +"%g %G %h %H %I"   # 20 2020 Jan 00 12
./datetime -d "2020-01-02" +"%j %k %l %m %M"   # 002  0 12 01 00
./datetime -d "2020-01-02" +"%n %N %p %P %q"   # newline 000000000 AM am 1
./datetime -d "2020-01-02" +"%r %R %s %S"      # 12:00:00 AM 00:00 1577919600 00
./datetime -d "2020-01-02" +"%t %T %u %U %V"   # tab 00:00:00 4 00 01
./datetime -d "2020-01-02" +"%w %W %x %X %y"   # 4 00 01/02/20 00:00:00 20
./datetime -d "2020-01-02" +"%Y %z %:z %::z %:::z %Z" # 2020 +0100 +01:00 +01:00:00 +01 CET
./datetime +"%Y-%m-%d %H:%M:%S.%N %z"         # nanoseconds + zone
# flags / width / modifiers
./datetime -d "2020-01-02" +"%_d"    # ' 2' space pad
./datetime -d "2020-01-02" +"%05d"   # '00002' zero pad width 5
./datetime -d "2020-01-02" +"%-5d"   # '2    ' no pad width 5
./datetime -d "2020-01-02" +"%^A"    # THURSDAY upper
./datetime -d "2020-01-02" +"%#A"    # opposite case
./datetime -d "2020-01-02" +"%+4Y"   # '+2020' plus for >4 digits
./datetime -d "2020-01-02" +"%10Y"   # '      2020' width 10
./datetime -d "2020-01-02" +"%Ey"    # alternative representation
./datetime -d "2020-01-02" +"%OY"    # alternative numeric
./datetime +"%Y%%m"                 # 2026%m (%% -> %)
./datetime -u -d "@0" +"%s.%N"      # 0.000000000
```

### Set time (requires root, otherwise warns but prints)
```sh
sudo ./datetime -s "2020-01-02 00:00:00"       # set system time
sudo ./datetime --set="2020-01-02" --debug    # with debug
./datetime 09091100                          # MMDDhhmm positional -> set Sep 09 11:00
./datetime 0909110000.00                     # MMDDhhmmYY.ss
```

### Error and exclusivity (mutually exclusive: `--date/--file/--reference/--resolution`)
```sh
./datetime -d "now" --file dates.txt         # fails: mutually exclusive
./datetime -d "now" -r ref --resolution      # fails
./datetime --iso-8601=invalid                # fails: invalid FMT
./datetime -d --file                         # fails: missing arg
./datetime --unknown                         # fails: unknown option
```

## Timestamp utility and microversion (`x.y.<UTC>`)

> **TL;DR for humans and LLMs:** `timestamp` = `YYYYMMDDhhmmssZ` – 14 digits + `Z` in **UTC**. It is the **micro-version**. Full version is `MAJOR.MINOR.TIMESTAMP`, e.g. `2.0.20260909083730Z` = major `2`, minor `0`, built `2026-09-09 08:37:30 UTC`. Easy to sort, easy to parse, no ambiguity.

### What it is

* **Two builds of one program:** `datetime` (local time `YYYYMMDDhhmmss`) and `timestamp`, the same source compiled with `-DDATETIME_TIMESTAMP_BUILD` so its default output is the UTC `YYYYMMDDhhmmssZ` stamp. Run-time behavior never depends on the program name (GNU Coding Standards §17) – the `--timestamp` flag selects the same format in *every* build.
* **Shell integration:** `make install` drops the bash completion script (`shell/datetime.bash`) into bash-completion's `completions` directory for both commands; without bash-completion, source it from your `~/.bashrc` (see the header of `shell/datetime.bash`).
* **Standard Python equivalent:** `python3 -c "import datetime; print(datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%SZ'))"`.

### How to use it

| Goal | Command | Output |
|------|---------|--------|
| **UTC micro-timestamp** | `./datetime --timestamp` or `./timestamp` | `20260909083730Z` |
| After `make` install | `timestamp` (or `$(prefix)/bin/datetime --timestamp`, e.g. `~/bin/datetime` with `PREFIX="$HOME"`) | `20260909083730Z` |
| Inside `datetime` format | `./datetime -u +"%Y%m%d%H%M%SZ"` | `20260909083730Z` |
| Python utility | `python3 -c "import datetime; print(datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%SZ'))"` | `20260909083730Z` |
| Build stamp | `__version__` in `datetime.c` | printed by `datetime --version` |

```sh
# 1. Direct binary (UTC, sortable)
./datetime --timestamp      # 20260909083730Z (UTC)
./timestamp                 # same, via the second build (make builds both)
PREFIX="$HOME"; $PREFIX/bin/datetime --timestamp     # same after PREFIX="$HOME" make install

# 2. As micro-version in your own script/SKILL
TS=$(~/sbin/datetime --timestamp 2>/dev/null || ./datetime --timestamp)   # TS=20260909083730Z
VERSION="2.0.$TS"                                  # 2.0.20260909083730Z

# 3. Python helper (standard library)
python3 - <<'PY'
import datetime
print(datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%d%H%M%SZ"))
PY

# 4. Parse it back (human or LLM): first 8 = date, next 6 = time, last Z = UTC
TS=20260909083730Z
echo $TS | sed -E 's/([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})Z/\1-\2-\3 \4:\5:\6 UTC/'
# -> 2026-09-09 08:37:30 UTC
```

### Why this exact form (`YYYYMMDDhhmmssZ`)?

We **chose this form on purpose** so both humans and LLMs can read it without guessing:

* **Sortable & filename-safe:** No `-`, `:`, `T`, or spaces. Lexicographic sort = chronological sort. Safe for filenames, Docker tags, SKILL metadata, `project.toml` `scheme = "x.y.micro"`. Compare `20260909083730Z` < `20260910120000Z` – no parsing needed.
* **Unambiguous timezone:** Trailing `Z` = *Zulu* = UTC (`format = "%Y%m%d%H%M%SZ"` + `gmtime`). No local `CEST`/`PST` confusion. LLM can instantly split: `YYYY` `MM` `DD` `hh` `mm` `ss` `Z`.
* **Compact but still human-readable:** 14 digits → split `YYYYMMDD` + `hhmmss`. Human scans `20260909` as `2026-09-09`, LLM tokenizes `2026 09 09 08 37 30 Z` without extra punctuation.
* **Micro-version semantics:** `x.y.micro` → `2.0.202609131714`:
  * `x.y` = API break / feature, `micro` = release date-time of this exact version. Both live in the single `__version__` constant in `datetime.c` – bump it when releasing; no build-time stamping.
* **Used everywhere in this repo:**
  * `datetime.c` `__version__` → `datetime --version` → `2.0.202609131714`
  * `project.toml` `scheme = "x.y.micro"` – docs for humans/LLMs how to interpret `2.0.*`
  * SKILL `writing-skills` / `tests-subfolder` prompts use `~/sbin/datetime --timestamp` to generate SKILL `__VERSION__` like `1.0.20260909104000Z`

**For LLM:** Treat `Z` as `UTC`, split `^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})Z$` → `YYYY-MM-DDThh:mm:ssZ` ISO. For human: read `20260909083730Z` as `2026-09-09 08:37:30 UTC` – the exact second this binary was built.

## Help files

Help is embedded in both binaries and also shipped as manual pages and tldr cheatsheets:

* **Binary help:** `./datetime --help` / `./datetime -h` and `./timestamp --help` / `./timestamp -h` (identical options; `timestamp` defaults to UTC `YYYYMMDDhhmmssZ`).
* **Man pages:** `man/man1/datetime.1` and `man/man1/timestamp.1` (installed to `$(mandir)/man1/` by `make install`; `timestamp.1` is a `.so` include of `datetime.1`). View with `man datetime` or `man timestamp`.
* **tldr pages:** `tldr/datetime.md` and `tldr/timestamp.md`.
* **Shell completion:** `shell/datetime.bash` – bash completion for both `datetime` and `timestamp` (installed to bash-completion's `completionsdir` as `datetime` and `timestamp`; without bash-completion, source it from `~/.bashrc` – see header of `shell/datetime.bash`).
* **Texinfo manual:** `manual.texi` → `datetime.info` (`make info`).

All help sources are generated from the same binary (`--help` is the single source of truth) and verified by `make check-docs`.
