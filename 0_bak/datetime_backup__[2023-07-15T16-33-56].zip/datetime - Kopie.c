#include <stdio.h>
#include <time.h>
#include <winbase.h>

int main() {
    time_t now;
    struct tm *timeinfo;
    char datetime[19];


    time(&now);
    timeinfo = localtime(&now);

    strftime(datetime, sizeof(datetime), "%Y%m%dT%H%M%S", timeinfo);

    // Store the current datetime in an environment variable
    // setenv(", datetime, 1);
	SetEnvironmentStrings("SetEnvironmentStrings", datetime, 1);

    printf("Current datetime: %s\n", datetime);

    return 0;
}